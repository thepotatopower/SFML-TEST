#pragma once
#include "key.h"

//key::key()
//{
//	this->collected = false;
//}

key::~key()
{

}

//void key::Collected()
//{
//	keys.setPosition(sf::Vector2f(20, 685));
//}