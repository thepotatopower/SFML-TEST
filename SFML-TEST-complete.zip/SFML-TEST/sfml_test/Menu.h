#pragma once
#include "SFML\Graphics.hpp"
#include <iostream>

using sf::Texture;
using sf::Sprite;
using sf::Font;
using sf::Text;
using sf::Window;
using sf::RenderWindow;
using sf::Clock;
using sf::Event;
using sf::VideoMode;
using sf::Color;
using sf::Mouse;
using sf::Vector2i;
using sf::Vector2f;
using std::cout;
using std::endl;


bool Menu();
